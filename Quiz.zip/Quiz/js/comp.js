
		// this is a questions array
	let questions = [
	{	num: 1,
		question : "RAM Stand For What",
		// imgSrc : "img/1.png",
		anSwer : "Random Access Memory",
		options: [
			"Real Action Marker",
			"Random Access Memory",
			"Real Audio Metafile",
			"Remote Authorization Mechanism"
		]
	},

	{
		num: 2,
		question : "PC Stand For What",
		// imgSrc : "img/1.png",
		anSwer : "Persional Computer",
		options: [
			"Poor Communication",
			 "Persional Computer",
			"Process Controllar",
			"Paper Cassette"
		]
	},
	{	
		num: 3,
		question : "CPU Stand For What",
		// imgSrc : "img/1.png",
		anSwer : "Central Processing Unit",
		options: [
			"Computer Part Unknown",
			"Core Processing Unit",
			"Central Processing Unit",
			"Computer Put To Use"
		]
	},
	{	
		num: 4,
		question : "ROM Stand For What",
		// imgSrc : "img/1.png",
		anSwer : "Read Only Memory",
		options: [
			"Ruens Of Magic",
			"Recent On Machine",
			"Really Odd Man",
			"Read Only Memory"
		]
	},
	{
		num: 5,
		question : "LED Stand For What",
		// imgSrc : "img/1.png",
		anSwer : "Light Emitting Diode",
		options: [
			"Laptop Entry Disc",
			"Laser Erasing Disc",
			"Light Emitting Diode",
			"Lighting Emitting Diodes"
		]
	}
]	
