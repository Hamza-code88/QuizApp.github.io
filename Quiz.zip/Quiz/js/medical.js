
		// this is a questions array
	let questions = [
	{	num: 1,
		question : "SGPT Stand For What",
		// imgSrc : "img/1.png",
		anSwer : "Serum Glutamate Pyruvate Transaminase",
		options: [
			"Conference Management System",
			"System gout patient Transaminase",
			"Serum getting points time",
			"Serum Glutamate Pyruvate Transaminase"
		]
	},

	{
		num: 2,
		question : "STD Stand For What",
		// imgSrc : "img/1.png",
		anSwer : "Sexually Transmitted Diseases",
		options: [
			 "Skin Test Dose",
			"Sexually Transmitted Diseases",
			"Digital Dynamic Sound",
			"Short Term Depression"
		]
	},
	{	
		num: 3,
		question : "CXR Stand For What",
		// imgSrc : "img/1.png",
		anSwer : "Chest X-ray",
		options: [
			"Sub System Hazard Analysis",
			"Chest X-ray",
			"Slow Sound Hurts Anatomy",
			"Cox Radio Inc"
		]
	},
	{	
		num: 4,
		question : "MLT Stand For What",
		// imgSrc : "img/1.png",
		anSwer : "Medical Lab Technication",
		options: [
			"The Musem System",
			"More Like This",
			"Really Odd Man",
			"Medical Lab Technication"
		]
	},
	{
		num: 5,
		question : "TDM Stand For What",
		// imgSrc : "img/1.png",
		anSwer : "Therapeutic Drug Monitoring",
		options: [
			"Twilight Dragon Media",
			"Totally Delightful Music",
			"Therapeutic Drug Monitoring",
			"Lighting Emitting Diodes"
		]
	}
]	
