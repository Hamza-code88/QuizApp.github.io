
		// this is a questions array
	let questions = [
	{	num: 1,
		question : "what does html stand for",
		// imgSrc : "img/1.png",
		anSwer : "Hyper Text Markup Language",
		options: [
			"Hello To My Love",
			"Hey Too Much Layout",
			"Hyper Text Markup Language",
			"khayper text markup language"
		]
	},

	{
		num: 2,
		question : "what does CSS stand for",
		// imgSrc : "img/1.png",
		anSwer : "Cascading Style Sheet",
		options: [
			"Content Scrambling System",
			"Cross Site Scripting",
			"Client Security Software",
			"Cascading Style Sheet"
		]
	},
	{	
		num: 3,
		question : "what does JS stand for",
		// imgSrc : "img/1.png",
		anSwer : "javascript",
		options: [
			"Joy Stick",
			"javascript",
			"Java Software",
			"Java Scripts"
		]
	},
	{	
		num: 4,
		question : "what does DDD stand for",
		// imgSrc : "img/1.png",
		anSwer : "Data display Debugger",
		options: [
			"Docs Data display",
			"Direct Distance Dialing",
			"Dot Density display",
			"Data display Debugger"
		]
	},
	{
		num: 5,
		question : "what does UI stand for",
		// imgSrc : "img/1.png",
		anSwer : "User Interface",
		options: [
			"universal interface",
			"User Interface",
			"user internet",
			"union interact"
		]
	}
]	
