
		// this is a questions array
	let questions = [
	{	num: 1,
		question : "CMS Stand For What",
		// imgSrc : "img/1.png",
		anSwer : "Conference Management System",
		options: [
			"Compact Music System",
			"Conference Management System",
			"College Music Society",
			"Church Missionary Society"
		]
	},

	{
		num: 2,
		question : "DDS Stand For What",
		// imgSrc : "img/1.png",
		anSwer : "Dark Duel Stories",
		options: [
			 "Dan Detictive School",
			"Dolbey Digital Sound",
			"Digital Dynamic Sound",
			"Dark Duel Stories"
		]
	},
	{	
		num: 3,
		question : "SSHA Stand For What",
		// imgSrc : "img/1.png",
		anSwer : "Social Science Histroy Association",
		options: [
			"Social Science Humanities And Arts",
			"Sub System Hazard Analysis",
			"Slow Sound Hurts Anatomy",
			"Social Science Histroy Association"
		]
	},
	{	
		num: 4,
		question : "TMA Stand For What",
		// imgSrc : "img/1.png",
		anSwer : "Training Management System",
		options: [
			"The Musem System",
			"Recent On Machine",
			"Really Odd Man",
			"Training Management System"
		]
	},
	{
		num: 5,
		question : "PMD Stand For What",
		// imgSrc : "img/1.png",
		anSwer : "Project Management Development",
		options: [
			"People Making Difference",
			"Laser Erasing Disc",
			"Project Management Development",
			"Lighting Emitting Diodes"
		]
	}
]	
