
		// this is a questions array
	let questions = [
	{	num: 1,
		question : "PSO Stand For What",
		// imgSrc : "img/1.png",
		anSwer : "Pakistan State Oil",
		options: [
			"Peace Support Operation",
			"Pakistan State Oil",
			"Public Service Obligation",
			"Provide Stamps Oil"
		]
	},

	{
		num: 2,
		question : "GOVT Stand For What",
		// imgSrc : "img/1.png",
		anSwer : "Government",
		options: [
			 "Skin Test Dose",
			"Give Take ",
			"Digital Dynamic Sound",
			"Government"
		]
	},
	{	
		num: 3,
		question : "NCS Stand For What",
		// imgSrc : "img/1.png",
		anSwer : "Non Copyright Sounds",
		options: [
			"Sub System Hazard Analysis",
			"Non Client Sample",
			"Slow Sound Hurts Anatomy",
			"Non Copyright Sounds"
		]
	},
	{	
		num: 4,
		question : "NOC Stand For What",
		// imgSrc : "img/1.png",
		anSwer : "No Objection Certificate",
		options: [
			"No option Case",
			"No Objection Certificate",
			"No Out Door",
			"Nepal Oil Corporation"
		]
	},
	{
		num: 5,
		question : "NTS Stand For What",
		// imgSrc : "img/1.png",
		anSwer : "National Testing Service ",
		options: [
			"New Typesting System",
			"Need To Sell",
			"Not To Sell",
			"National Testing Service "
		]
	}
]	
