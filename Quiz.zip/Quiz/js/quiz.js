// let audioElement = new Audio('songs/1.mp3'); if you want to play background music


	let element = new Audio('songs/2.wav');
	let clickv = new Audio('songs/5.wav');



	// this is vars
const star_btn = document.querySelector(".start-btn");
const info_box = document.querySelector(".info-box");
const exit_btn = info_box.querySelector(".button .quit");
const contineu_btn = info_box.querySelector(".button .restart");
const option_list = document.querySelector(".option-list");

const quiz_box = document.querySelector(".quiz-box");
const timeCount = quiz_box.querySelector(".timer .timer-sec");
const time_line = quiz_box.querySelector("header .time-line");
const timeOff = quiz_box.querySelector("header .t-text");



// music controles
const mute_bg = document.querySelector(".mute");
const soundOff = document.querySelector(".sound");

	 // for menu controles
	 const menu = document.querySelector(".menu");
	 const nav = document.querySelector(".nav");
	 const close = document.querySelector(".close");
	 menu.onclick = ()=>{
		menu.style.display = "none";
		nav.style.display = "block";
		// audioElement.play();
		element.play();
	}

	 close.onclick = ()=>{
		menu.style.display = "block";
		nav.style.display = "none";
		// audioElement.play();

		element.play();
	}

		// this is a questions array
	


	// buttons clicks events

	// start button
	star_btn.onclick = ()=>{
		star_btn.style.display = "none";
		info_box.style.display = "block";
		// audioElement.play();
		nav.style.opacity = 0;
		menu.style.opacity = 0;
		element.play();
	}


	info_box.onclick = ()=>{
		star_btn.style.display = "block";
		info_box.style.display = "none";
		element.play();
	}

	contineu_btn.onclick = ()=>{
		star_btn.style.display = "none";
		info_box.style.display = "none";
		quiz_box.style.display = "block";
		element.play();
		showquestions(0);
		quecounter(1);
		startTimer(15);
		startTimerLine(0);
	}

	option_list.onclick = ()=>{
		clickv.play();
	}


	let que_count = 0;
	let que_num = 1;
	let counter;
	let counterLine;
	let timeValue = 15;
	let widthValue = 0;
	let userScore = 0;
	


	const next_btn = quiz_box.querySelector(".btn-next");
	const result_box = document.querySelector(".result-box");
	const restart_quiz = result_box.querySelector(".button .restart");
	const quit_quiz = result_box.querySelector(".button .quit");


	restart_quiz.onclick = () =>{
		result_box.style.display = "none";
		element.play();
		quiz_box.style.display = "block";
	let que_count = 0;
	let que_num = 1;
	let timeValue = 15;
	let widthValue = 0;
	let userScore = 0;

	showquestions(que_count);
			quecounter(que_num);
			clearInterval(counterLine);
			startTimerLine(widthValue);
			timeOff.textContent = "Time Left";
	}

	quit_quiz.onclick = () =>{
		element.play();
		menu.style.opacity = 1;
		nav.style.opacity = 1;
		window.location.reload();
		
	}

	next_btn.onclick = ()=>{
		// que_count++;
		// showquestions(que_count); 
		element.play();

		if (que_count < questions.length - 1) {
			que_count++;
			que_num++;
			showquestions(que_count);
			quecounter(que_num);
			clearInterval(counterLine);
			startTimerLine(widthValue);
			// clearInterval(counterLine);
			timeOff.textContent = "Time Left";
		}else{

			clearInterval(counterLine);
			clearInterval(counterLine);
			console.log("questions completed");
			showresultBox();
		}
	}



	// get question arry
	function showquestions(index) {
		const que_text = document.querySelector(".que-text");
		
		let que_tag = '<span>' + questions[index].num + "." + questions[index].question +'</span>';
		let option_tag = '<div class="option">'+ questions[index].options[0] +'<span></span>	</div>'
				+ '<div class="option">'+ questions[index].options[1] +'<span></span></div>'
				+ '<div class="option">'+ questions[index].options[2] +'<span></span></div>'
				+ '<div class="option">'+ questions[index].options[3] +'<span></span></div>';
		que_text.innerHTML = que_tag;
		option_list.innerHTML = option_tag;

		const option = option_list.querySelectorAll(".option");
		for (let i = 0; i < option.length; i++) {
			option[i].setAttribute("onclick", "optionSelected(this)");
		}
	}


	let tickicon = '<div class="icon"><span class="ic">&check;</span></div>';
	let crosicon = '<div class="icon"><span class="ic">&times;</span></div>'

	function optionSelected(anSwer) {
		clearInterval(counter);
			clearInterval(counterLine);
		let userAns = anSwer.textContent;
		let correctAns = questions[que_count].anSwer;
		let alloptions = option_list.children.length;
	
		if (userAns == correctAns) {
				userScore += 1;
				console.log(userScore);
			anSwer.classList.add("correct");
			console.log("correctAns");
			anSwer.insertAdjacentHTML("beforeend", tickicon);
		}
		else{
			anSwer.classList.add("incorrect");
			console.log("no ans");
			anSwer.insertAdjacentHTML("beforeend", crosicon);
			for (let i = 0; i < alloptions; i++) {
			if (option_list.children[i].textContent == correctAns) {
				option_list.children[i].setAttribute("class", "option correct");
				option_list.children[i].insertAdjacentHTML("beforeend", tickicon);
			}
		  }
		}


		for (let i = 0; i < alloptions; i++) {
			option_list.children[i].classList.add("disabled");
		}
		next_btn.style.display = "block";
	}


	function showresultBox() {
		// info_box.classList.remove("activeinfo");
		// quiz_box.classList.remove("activequiz");
		// result_box.classList.add("activeresult");
		result_box.style.display = "block";

		const scoreText = result_box.querySelector(".score-text");

		if (userScore > 3) {
			let scoretag = '<span>and congrats you got only <p>'+ userScore +'</p> out of <p>'+ questions.length +'</p></span>';

			scoreText.innerHTML = scoretag;
		}
		else if(userScore > 1) {
			let scoretag = '<span>and nice you got only <p>'+ userScore +'</p> out of <p>'+ questions.length +'</p></span>';

			scoreText.innerHTML = scoretag;
		}
		else{
			let scoretag = '<span>and sorry you got only <p>'+ userScore +'</p> out of <p>'+ questions.length +'</p></span>';

			scoreText.innerHTML = scoretag;
		}
	}

	function startTimer(time) {
		counter = setInterval(timer, 1000);
		function timer() {
			timeCount.textContent = time;
			time--;
			if (time < 9) {
				let addZero = timeCount.textContent;
				timeCount.textContent = "0" + addZero;
			}
			if (time < 0) {
				clearInterval(counter);
				timeCount.textContent = "00";
				timeOff.textContent = "Time Off";

				let correctAns = questions[que_count].anSwer;
				let alloptions = option_list.children.length;
	

				for (let i = 0; i < alloptions; i++) {
			if (option_list.children[i].textContent == correctAns) {
				option_list.children[i].setAttribute("class", "option correct");
				option_list.children[i].insertAdjacentHTML("beforeend", tickicon);
			}
		  }

		  for (let i = 0; i < alloptions; i++) {
			option_list.children[i].classList.add("disabled");
		}
		next_btn.style.display = "block";
			}
		}
	}

	function startTimerLine(time) {
		counterLine = setInterval(timer, 29);
		function timer() {
			time += 1;
			time_line.style.width = time + "px";
			if (time > 549) {
				clearInterval(counterLine);
				
			}
		}
	}




	function quecounter(index) {
		const total_que = quiz_box.querySelector(".total-que");
	let total_que_count = '<span><p>'+ index + '</p>of <p>'+ questions.length + '</p>Question</span>';
	total_que.innerHTML = total_que_count;
	}